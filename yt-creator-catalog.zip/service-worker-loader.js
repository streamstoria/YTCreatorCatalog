import './src/background/background.js';
